// load sample data for students and instructors map reduce examples
db.students.drop();
db.students.insertMany([
{  "name" : "Marko", 
   "courses" : [ { "courseid" : 300, "grade" : "A" }, 
                 { "courseid" : 363, "grade" : "F" },
                 { "courseid" : 370, "grade" : "B" },
                 { "courseid" : 338, "grade" : "A" }                 
                ] 
},
{  "name" : "Paul", 
   "courses" : [ { "courseid" : 300, "grade" : "C" }, 
                 { "courseid" : 370, "grade" : "F" },
                 { "courseid" : 338, "grade" : "B" } 
               ] 
},
{  "name" : "Peter", 
   "courses" : [ { "courseid" : 300, "grade" : "B" }, 
                 { "courseid" : 363, "grade" : "A" },
                 { "courseid" : 370, "grade" : "A" },
                 { "courseid" : 338, "grade" : "A" } 
               ] 
}, 
{  "name" : "Mary", 
   "courses" : [ { "courseid" : 363, "grade" : "A" }, 
                 { "courseid" : 370, "grade" : "B" },
                 { "courseid" : 338, "grade" : "B" } 
                ] 
}
]);

db.instructors.drop();
db.instructors.insertMany([
{  "name" : "Tao", "courses" : [ 300, 363 ] },
{  "name" : "Byun", "courses" : [ 338, 370 ] }
]);

// load sample data for friends 
db.names.drop()
db.names.insertMany([
{  "name" : "Dave", "friends" : [ "Mack", "Mora" ], "age" : 67 },
{  "name" : "Amy", "friends" : [ "Barry", "Betty" ], "age" : 45 },
{  "name" : "Cynthia", "friends" : [ "Morgan", "Morse", "Lewis" ], "age" : 45 },
{  "name" : "Vera", "friends" : [ "Hope", "Stanley", "Barry" ], "age" : 45 },
{  "name" : "Wanda", "friends" : [ "Kyle", "David" ], "age" : 68 },
{  "name" : "Barry", "friends" : [ "Hope", "Betty", "Mora" ], "age" : 45 },
{  "name" : "Mack", "friends" : [ "Morse", "Lewis", "Kyle" ], "age" : 45 },
{  "name" : "Zeke", "friends" : [ "Hope", "Morgan", "Mack" ], "age" : 45 },
{  "name" : "Mora", "friends" : [ "Morgan", "Morse", "Kyle" ], "age" : 67 },
{  "name" : "Betty", "friends" : [ "Barry",  ], "age" : 68 },
{  "name" : "Morgan", "friends" : [ "Hope", "Stanley",  ], "age" : 45 },
{  "name" : "Stanley", "friends" : [ "Hope", "Betty",  "Barry" ], "age" : 44 },
]);

