// example 2
// calculate average number of friends per name in the names collection.
// to calculate average we calculate 
//   * the total number of friends in the collection 
//   * divided by the number of name documents
// the final answer is a single number.  There is no grouping.
// So for an emit key, use constant 0.
// The value emitted needs to include both sum and count we can be combined 
// in reduce to an overall sum and count to get the average.
// Note:  you cannot combine averages from partial reduces, you need 
// to know the sum and count of the partial reduce.
 
mapf2 = function() {
  emit(0, {sum:this.friends.length, count:1} )
}

// summarize the input data which consists of 
// key:0
// values: [{sum:, count: }, {sum:, count: }, . . . ]
// combine all sum values, and all count values.
reducef2 = function(key, values){
  count=0;
  sum=0;
  for (x of values){
    sum += x.sum;
    count += x.count;
  }
  return {sum: sum, count: count, average: (sum/count).toFixed(2)}
}

db.names.mapReduce(mapf2, reducef2, {out:"example2_output"});

// print output 
q = db.example2_output.find();
while ( q.hasNext() ){
  print(JSON.stringify(q.next()));
}