// count number of occurences of each name in friends list
//
// the map function is called by MongoDB for each document 
//  the document is assigned to the "this" variable
//  map function needs to "emit" (key:value) pairs for each 
//  friend in the friends list.  The reduce key should be the string 
//  of the friend.  The value is 1

mapf1 = function() {
	for (f of this.friends) {
		emit(f, 1);
	}
}

// mongodb then groups by key and passes the key and list to reduce function
//  example call  friend="Betty", values=[1, 1, 1, 1]
// reduce is reponsible to summarize the list and return a single value
reducef1 = function( friend, values) {
	// sum up the list of values
	let total = 0;
	for (value of values) {
		total = total + value;
	}
	return total;
}
//  perform map-reduce operation,  output goes to "temp1" collection
db.names.mapReduce(mapf1, reducef1, {out:"temp1"});

cursor = db.temp1.find();
while (cursor.hasNext()) {
	print(JSON.stringify(cursor.next()));
}