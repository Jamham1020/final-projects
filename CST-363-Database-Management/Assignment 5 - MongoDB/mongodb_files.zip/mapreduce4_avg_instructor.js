// example 4
// grade average by instructor

// calculate average grade by course
//{  "name" : "Marko", 
//   "courses" : [ { "courseid" : 300, "grade" : "A" }, 
//                 { "courseid" : 363, "grade" : "B" } ] }

// we need to join collections based on courseid
// use courseid as reduce-key in map-reduce 

// step1 . map-reduce over students collection.
const mapf4 = function() {
  let grades={"A":4.0, "B":3.0, "C":2.0, "D":1.0, "F":0.0}
  for (let course of this.courses) {
    let grade = grades[course.grade]
    emit(course.courseid, {sum:grade, count:1} );
  }
}

// step 1a. reduce over students collection
// for each course, sum of grades, count of students.
const reducef4 = function(key, emits) {
  let sum = 0;
  let count = 0;
  for (let x of emits) {
    sum = sum + x.sum;
    count = count + x.count;
  }
  return {sum:sum, count:count}
}

db.students.mapReduce(mapf4, reducef4, {out:"temp1"})
//  temp1 should now contain 
//  {_id:300, value: {sum:24.0, count:10}
//  {_id:363, value: {sum: 35.0, count:14}
//    ..... 

// step 2 
// merge with course instructor
// {  "name" : "Tao", "courses" : [ 300, 363 ] }

// map reduce over the instructors collection.
//   use reduce-key of courseid
const mapf5 = function() {
  for (let courseid of this.courses){
    emit(courseid, {name:this.name});
  }
}

// merge 
//  {_id:300, value: {name:"Tao"}}  from mapf5
//  {_id:300, value: {sum:24.0, count:10} from reducef4
//   
// the value of emits will be both the output of map reduce line 33, and the emits from mapf5. 
//  [  {name:"Tao"}, {sum:24.0, count:10} ]
const reducef5 = function(key, emits) {
  let sum = 0;
  let count = 0;
  let name = "";
  for (let x of emits) {
    if ("sum" in x) {  // does x contain the attribute "sum"?
      sum = sum + x.sum;
      count = count + x.count;
    }
    if ("name" in x && x.name != "") {  // does x contain a "name" attribute?
      name = x.name;
    }
  }
  return {sum:sum, count:count, name:name}
}

// this map reduce goes to the same output collection as the map reduce over students.
//  use the option {out: {reduce: [out collection name]}}
db.instructors.mapReduce(mapf5, reducef5, {out: {reduce:"temp1"}}); 

// for debugging, let's see what is in "temp1"
q=db.temp1.find();
print("Debug.  Temp1 contains the following.");
while(q.hasNext()){
	print(JSON.stringify(q.next()));
}
print("Debug. End of temp1.");

// Now summarize the data in temp1 by instructor name.
//  temp1 documents are of the form 
// {_id:[course id], value: {sum: [grade sum], count: [student count], name:[instructor name]} }

const mapf6 = function() {
  emit(this.value.name, {sum:this.value.sum, count:this.value.count}) 
}

// key is instructor name
// emits is list of [ {sum:, count: }...] coming from emit in mapf6
const reducef6 = function(key, emits) {
  let sum=0;
  let count=0;
  for (let x of emits) {
    sum += x.sum;
    count += x.count;
  }
  return {sum:sum, count: count, average:(sum/count).toFixed(2)}
}

print("Average grade by instructor")
db.temp1.mapReduce(mapf6, reducef6, {out:"temp2"})
q = db.temp2.find();
while ( q.hasNext() ){
  print(JSON.stringify(q.next()));
}







