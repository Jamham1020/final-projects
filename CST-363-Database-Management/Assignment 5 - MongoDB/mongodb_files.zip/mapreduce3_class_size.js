// example 3  
// for each class, class size and passing rate 
// {  "name" : "Marko", 
//    "courses" : [ { "courseid" : 300, "grade" : "A" }, 
//                  { "courseid" : 363, "grade" : "B" } ]}

//  output will show
//   {_id:  300,  count: 30, pass: 25,  passrate:.75}

const mapf = function() {
  for (let course of this.courses) {
    let p = (course.grade < 'D') ? 1 : 0;  // p=1 for pass grade
    emit(course.courseid, {count:1, pass:p} );
  }
}


const reducef = function(key, emits){
  let count=0;
  let pass=0;
  for (let x of emits){
    count = count + x.count;
    pass = pass + x.pass;
  }
  return {count:count, pass: pass, passRate:(pass/count).toFixed(2)}
}


print("Map reduce on students collection.")
db.students.mapReduce(mapf, reducef, {out:"example3_output"});
q = db.example3_output.find();
while ( q.hasNext() ){
  print(JSON.stringify(q.next()));
} 