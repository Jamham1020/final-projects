// example 1  
// Count number of people of each age
// Documents in collection are of the form
// output key=age, value=1 
mapf = function() {
  emit(this.age, 1)
}

// the key, value from map are sorted and grouped by age 
// and passed to reduce function
// key = age, values=[ 1, 1, 1, ..... ]
// reduce returns the sum of the values list

reducef = function(key, values){
  count=0;
  for (x of values){
    count = count + x;
  }
  return count;
}

// testing the map function to verify what is being emitted.
// override the mongo "emit" function with a function that prints arguments 

emit = function(key, value) {
  print("key:", key, "value:");
  print(JSON.stringify(value));
}  

// test the mapf function
print("Map test:");
q = db.names.find();
while (q.hasNext()) {
  doc = q.next();
  print(JSON.stringify((doc)));
  mapf.apply(doc);
}

// test reducef function to verify it is correctly summarizing the value list.
print("Reduce test:");
result =  reducef( 45, [1, 1, 1, 5, 1, 1, 1, ] );
print("Result should be 11.  Actual result is "+result);

// end of test 

db.names.mapReduce(mapf, reducef, {out:"example1"});

// print output of map reduce
q = db.example1.find();
print("Output from map reduce.");
while ( q.hasNext() ){
  print(JSON.stringify(q.next()));
}

