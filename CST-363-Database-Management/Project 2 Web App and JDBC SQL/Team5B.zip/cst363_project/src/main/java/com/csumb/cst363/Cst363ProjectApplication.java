package com.csumb.cst363;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cst363ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cst363ProjectApplication.class, args);
	}

}
