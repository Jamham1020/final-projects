package com.csumb.cst363;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller   
public class ControllerPrescriptionFill {

   //function to check input strings for illegal characters
   public boolean stringCheck(String input)
   {
      String illegal = "<>&”’()#&;+-";
      boolean charIllegal = false; 
       
      
      for(int i = 0; i < input.length(); i++)
      {
         for( int j = 0; j < illegal.length(); j++)
         {
            if(input.charAt(i) == illegal.charAt(j))
            {
               charIllegal = true;
            }
         }
      }
      
      return charIllegal; 
   }
   
   
	@Autowired
	private JdbcTemplate jdbcTemplate;


	/* 
	 * Patient requests form to search for prescription.
	 */
	@GetMapping("/prescription/fill")
	public String getfillForm(Model model) {
		model.addAttribute("prescription", new Prescription());
		return "prescription_fill";
	}


	/*
	 * Process the prescription fill request from a patient.
	 * 1.  Validate that Prescription p contains rxid, pharmacy name and pharmacy address
	 *     and uniquely identify a prescription and a pharmacy.
	 * 2.  update prescription with pharmacyid, name and address.
	 * 3.  update prescription with today's date.
	 * 4.  Display updated prescription 
	 * 5.  or if there is an error show the form with an error message.
	 */
	@PostMapping("/prescription/fill")
	public String processFillForm(Prescription p,  Model model) {
	   
	   
	   
	   boolean error = false;
	   
      try (Connection con = getConnection();) {
         
         // make sure no input has illegal characters
         if(stringCheck(p.getRxid()) == true)
         {
            model.addAttribute("message", "Illegal character in Rx number input");
            return "prescription_fill";
         }
         if(stringCheck(p.getPatientLastName()) == true)
         {
            model.addAttribute("message", "Illegal character in patient last name input");
            return "prescription_fill";
         }
         if(stringCheck(p.getPharmacyName()) == true)
         {
            model.addAttribute("message", "Illegal character in pharmacy name input");
            return "prescription_fill";
         }
         if(stringCheck(p.getPharmacyAddress()) == true)
         {
            model.addAttribute("message", "Illegal character in pharmacy address input");
            return "prescription_fill";
         }

         //check for valid existing prescription id
         PreparedStatement ps = con.prepareStatement("select rxid from prescription where rxid = ?");
         ps.setString(1,  p.getRxid());
         ResultSet rs = ps.executeQuery();
         
         // if prescription id doesn't exist show error
         if(rs.next() == false)
         {
            model.addAttribute("message", "Prescription not found");
            error = true;
         }
         //check that patientid exists in the prescription from input patient last name
         ps = con.prepareStatement("select patientId from patient where last_name = ?");
         ps.setString(1,  p.getPatientLastName());
         rs = ps.executeQuery();
         
         if(rs.next() == false)
         {
            model.addAttribute("message", "Patient not found");
            return "prescription_fill";
         }
         int patientId = rs.getInt(1);
         
      ps = con.prepareStatement("select patientId from prescription where patientId = ? and rxid = ?");
         ps.setInt(1,  patientId);
         ps.setInt(2, Integer.valueOf(p.getRxid()));
         rs = ps.executeQuery();
         
         if(rs.next() == false)
         {
            model.addAttribute("message", "No matching rxid for patient");
            error = true;
         }
         //check that prescription id is not bland
         if(p.getRxid().isBlank() == true)
         {
            model.addAttribute("message", "Prescription number blank");
            error = true;
         }
         //check that pharmacyname is not blank
         if(p.getPharmacyName().isBlank() == true)
         {
            model.addAttribute("message", "Pharmacy name blank");
            error = true;
         }
         //check that pharmacy adress is not blank
         if(p.getPharmacyAddress().isBlank() == true)
         {
            model.addAttribute("message", "Pharmacy Address blank");
            error = true;
         }

         //check that pharmacyname exists in table
         ps = con.prepareStatement("select pharmacyname from pharmacy where pharmacyname = ?");
         ps.setString(1,  p.getPharmacyName());
         rs = ps.executeQuery();
         
         //error for invalid pharmacy
         if(rs.next() == false)
         {
            model.addAttribute("message", "Pharmacy not found");
            error = true;
         }
         // make sure pharmacy address matches pharmacy in table
         ps = con.prepareStatement("select pharmacyid from pharmacy where pharmacyaddress = ?");
         ps.setString(1,  p.getPharmacyAddress());
         rs = ps.executeQuery();
         int pharmacyId = 0;
         
         //message for invalid address
         if(rs.next() == false)
         {
            model.addAttribute("message", "Pharmacy address not found");
            error = true;
         }
         else 
         {
            //if address is valid set the pharmacy id to the id associated with address
            pharmacyId = rs.getInt(1);
         }
         
         //if there are no errors update filled with pharmacy and prescription information and current date
         if(error == false)
         {
            Date dt = new Date(System.currentTimeMillis());
            java.sql.Date sqldate = new java.sql.Date(dt.getTime());
            
            
            ps = con.prepareStatement("insert into filled(datefilled, rxid, pharmacyid) values(?, ?, ?)");
            ps.setDate(1,  sqldate);
            ps.setInt(2,  Integer.valueOf(p.getRxid()));
            ps.setInt(3, pharmacyId);

            ps.executeUpdate();
            
            //get prescription information from row to fill completed form with
            ps = con.prepareStatement("select doctor.ssn, doctor.first_name, doctor.last_name, patient.ssn, patient.first_name, patient.last_name, drug.trade_name, "
                  + "prescription.quantity, pharmacy.pharmacyid, pharmacy.pharmacynumber, filled.pharmacyid from prescription "
                  + "join doctor on prescription.doctorId = doctor.id join patient on prescription.PatientId = patient.patientId join drug on prescription.drugId = drug.drug_id "
                  + "join filled on prescription.rxid = filled.rxid join pharmacy on filled.pharmacyid = pharmacy.pharmacyid where prescription.rxid = ?");
            ps.setString(1,  p.getRxid());
            rs = ps.executeQuery();
            rs.next();
            
            p.setDoctor_ssn(rs.getString(1));
            p.setDoctorFirstName(rs.getString(2));
            p.setDoctorLastName(rs.getString(3));
            p.setPatient_ssn(rs.getString(4));
            p.setPatientFirstName(rs.getString(5));
            p.setPatientLastName(rs.getString(6));
            p.setDrugName(rs.getString(7));
            p.setQuantity(rs.getInt(8));
            p.setPharmacyID("" + rs.getInt(9));
            p.setPharmacyPhone("" + rs.getString(10));
            p.setDateFilled("" + dt);
            
            
            model.addAttribute("message", "Prescription has been filled.");
            model.addAttribute("prescription", p);
            
            ps = con.prepareStatement("update prescription set filled = 'yes' where rxid = ?");
            ps.setInt(1, Integer.valueOf(p.getRxid()));
            ps.executeUpdate();
         }
         //if error in input, show fill form
         else
         {
            return "prescription_fill";
         }

         
       
            
      } 
      //sql error catch
      catch (SQLException e) 
      {
         model.addAttribute("message", "SQL Error."+e.getMessage());
         model.addAttribute("prescription", p);
         return "prescription_fill";  
      }
	   
		// TODO complete - Ben

		// temporary code to set fake data for now.
		// p.setPharmacyID("70012345");
		// p.setCost(String.format("%.2f", 12.5));
		// p.setDateFilled( new java.util.Date().toString() );

		// display the updated prescription
      return "prescription_show";

	}

	/*
	 * return JDBC Connection using jdbcTemplate in Spring Server
	 */

	private Connection getConnection() throws SQLException {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		return conn;
	}

}