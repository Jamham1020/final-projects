package com.csumb.cst363;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class DataGenerate
{

   static final String DBURL = "jdbc:mysql://localhost:3306/cst363";  // database URL
   static final String USERID = "root";
   static final String PASSWORD = "i8pizza2";
   
   //stores ssn numbers to ensure duplicates are not created
   static int[] ssnNums;
   static int ssnNumsIndex;
   
   //generate a birthday
   static String generateBirthday()
   {
      Random genYear = new Random();
      Random genMonth = new Random();
      Random genDate = new Random();
      
      int year; 
      int month;
      int date; 
      
      
      year = genYear.nextInt(2000 - 1900) + 1900;
      month = genMonth.nextInt(12 - 1) + 1;
      date = genDate.nextInt(29 - 1) + 1;
      
      String birthdate = year + "-" + month + "-" + date; 
      
      return birthdate;
      
   }
   
   static String generatePrescribedDate()
   {
      Random genYear = new Random();
      Random genMonth = new Random();
      Random genDate = new Random();
      
      int year; 
      int month;
      int date; 
      
      
      year = genYear.nextInt(2022 - 2021) + 2021;
      month = genMonth.nextInt(12 - 1) + 1;
      date = genDate.nextInt(29 - 1) + 1;
      
      String prescribedDate = year + "-" + month + "-" + date; 
      
      return prescribedDate;
      
   }
   
   //generate a unique ssn by checking against already created ssns 
   static String generateSsn()
   {
      Random genSsn = new Random(); 
      ssnNums[ssnNumsIndex] = genSsn.nextInt(10000);
      
      for (int i = 0; i < ssnNumsIndex; i++)
      {
         int temp = ssnNums[ssnNumsIndex];
         
         if(temp == ssnNums[i])
         {
            generateSsn();
         }
         else if (i == ssnNumsIndex - 1)
         {
            i = ssnNumsIndex;
         }
      } 

      int ssnNum = 123450000 + ssnNums[ssnNumsIndex];
      String ssn = "" + ssnNum;
      ssnNumsIndex++;
      
      
      return ssn;
      
   }
  // generate a random phonenumber 
   static String generatePhonenumber()
   {
      Random genPhn = new Random();
      
      String phoneNumber = "" + (genPhn.nextInt(999 - 100) + 100);
      phoneNumber += "-" + (genPhn.nextInt(999 - 100) + 100);
      phoneNumber += "-" + (genPhn.nextInt(9990 - 1000) + 1000);
      
      
      return phoneNumber;
   }
      
            
        
  
   
   public static void main(String[] args) {
      
      ssnNums = new int[1000];
      
      //set of names for first and last name generation
      String[] names = new String[] {"Bill", "Jane", "Paul", "Alex", "Kate", "Austin", "Walter",
            "Chris", "Cassie", "Wilfred", "Alfred", "Dane", "Brad", "Jeff", "Abby",
            "Alice", "Laura", "Lauren", "Betty", "Betsy", "Dave", "David", 
            "Jonathan", "Will", "Aris", "Crystal", "Jennifer", "Lopez", "Blaze", 
            "Boomer", "Grace", "Gabby", "Audrey", "Wesly", "Gary", "Harry", "Tina", 
            "Tony", "Bob", "Robert", "Celeste", "Carly", "Allen", "Tim", "Greg",
            "Janice", "Marsha", "Bobby", "Cindy", "Kate", "John", "Cary", "Smith", 
            "Pitt", "Damon", "Willis", "Disney", "Collins", "Bethany", "Lock", 
            "Peter", "Toby", "Kirsten", "Dunst", "Ashley", "Mickey", "Robinson", 
            "Wislow", "Walker", "Klepeck", "Pack", "Tracy", "Morgan", "Rock", 
            "Sam", "Samuel", "Jessie", "Kopack", "Ron", "Ronald", "Clay", 
            "Aidan", "Reis", "Nicole", "Chloe", "Nick", "Amanda", "Antonio",
            "Pan", "Larry", "Jason", "Lilly", "Daisy", "Dwayne", "Chester", 
            "Brittany", "Kat", "Stacy", "Lilo", "Timothy", "Bert", "Homer",
            "Marge", "Rami", "Lupita", "Alba", "Janelle", "Kurt", "Timmy", 
            "Minnie", "Evan", "Clint", "Liam", "Olivia", "Noah", 
            "Emma", "Oliver", "Charlotte", "Elijah", "Amelia", "James", "Ava",
            "Sophia", "Isabella", "Lucas", "Mia", "Henry", "Griffin", "Evelyn",
            "Theodore", "Harper", "Joseph", "Karen", "Nancy", "Betty", "Margaret",
            "Mark", "Kimberly", "Emily", "Donna", "Michelle", "Carol", "Amanda"};
      
      // set of states for state generation
      String[] states = new String[] {"Alabama","Alaska",
            "Arizona","Arkansas","California","Colorado","Connecticut",
            "Delaware","Florida","Georgia","Hawaii","Idaho","Illinois",
            "Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine",
            "Maryland","Massachusetts","Michigan",
            "Minnesota","Mississippi", "Missouri","Montana","Nebraska",
            "Nevada","New Hampshire","New Jersey","New Mexico","New York",
            "North Carolina", "North Dakota","Ohio",
            "Oklahoma", "Oregon","Pennsylvania","Rhode Island",
            "South Carolina","South Dakota","Tennessee","Texas","Utah",
            "Vermont","Virgin Island","Virginia","Washington","West Virginia"
            ,"Wisconsin","Wyoming"};
      
      //set of street names for address generation
      String[] streets = new String[] {"Newark Dr.", "Jefferson Ave.", 
            "Lawrence St.", "Butterfly Ave.", "Bubblegum Ln.", "Main Dr.",
            "Collins St.", "Oregano Ave.", "Orangethorpe Dr.", 
            "Thunderbird Rd.", "Gallant Ln.", "Piccolo Dr.", "Galaxy Ln.",
            "Greedo Dr.", "B St.", "C St.", "D St.", "E St.", "Washington Ave", 
            "Riverside Dr.", "Bourbon St.", "Hollywoord Blvd.", "Abbey Rd.", 
            "Lombard St.", "Adam St.", "Abbey St.", "Albert St.", "Albion Rd.",
            "Alfred St.", "Alexander St.", "Allen St.", "Angel Ct.", "Bell Ct.",
            "Berwick St.", "Berkley St.", "Bishop Rd.", "Bond St.", 
            "Brewer St.", "Bridge Rd.", "Broadway", "Bruswick Ave.",
            "Cambridge Rd.", "Camden St.", "Castle St.", "Chapel St.", 
            "Charles St.", "Charlton St.", "Chester St.", "Church Ln",
            "Clifton St.", "College Ave.", "Compton St.", "Coopers Rd.", 
            "Crescent Pl.", "Cross Ct.", "Crown Ct.", "Dean St.", "Dafoe Rd.", 
            "Dorset St.", "Eagle St.", "Edward St.", "Eldon Rd.", "Elm St.", 
            "Field Pl.", "Finch St.", "Fountain Ct.", "George St.", "Globe Ct.",
            "Grey St.", "Grey Ct.", "Lawrence Ct.", "Butterfly Ct.", 
            "Newark Ave.", "Gallant Dr.", "Alexander Ct.", "George Ave.", 
            "Alfred Ct."};
            //set of cities for address generation
      String[] cities = new String[] {"Temecula", "Apple Valley", "Hesperia", 
            "Riverside", "San Diego", "Los Angeles", "Murrieta", "Hemet", 
            "San Bernardino", "Los Gatos", "Santa Monica", "Monterey", 
            "Santa Cruz", "San Fransisco", "Las Vegas", "Greenwich",
            "Hartford", "Mansfield", "Manchester", "Derby", "Danbury", 
            "Enfield", "Fairfield", "Middletown", "Norwich", "Orange",
            "Shelton", "Waterbury", "Westport", "Windham", "Dover",
            "Clearwater", "Cocoa Beach", "Key West", "Lake Wales", 
            "Largo", "Miami", "Naples", "Chicago", "Tampa", "Venice", 
            "Winter Park", "Albany", "Calhoun", "Dalton", "Plains"};
            //set of doctor specialties for randomly generated doctor
      String[] specialties= {"Internal Medicine", "Family Medicine",
            "Pediatrics", "Orthpedics", "Dermatology", "Cardiology",
            "Gynecology", "Gastroenterology", "Psychiatry", "Oncology"};
      
         // set of pharmacy names 
      String[] pharmacies = {"Wholesale Pharmacy", "Waldos Pharmacy", 
            "Pillmart", "Liquid Markey", "Bullseye Pharmacy", "Medicine Markey",
            "MartWal Pharmacy", "Presctiption Fillers", "Bottle Pharmacy", 
            "Doctor Market"};
      
      //patient data
      String lastName;
      String firstName;
      String birthdate;
      String dssn;
      String pssn;
      String street; 
      String city;
      String state; 
      String zipcode;
      
      //doctor data
      int primaryId; 
      String primaryName;
      String speciality;
      String years;
      
      
      Random gen = new Random();   
      
     int test = 0; 
     int address = 0;
     int zip = 0;
     
     Random genAddress = new Random();

      
      try (Connection conn = DriverManager.getConnection(DBURL, USERID, PASSWORD);) {
         

         PreparedStatement ps;
         PreparedStatement ps2; 
         ResultSet rs;
         String[] keycols2 = {""};
         //result set for Dr
         ResultSet drs;
         int id;
         int row_count;
         
         Statement st = conn.createStatement();
         
         String sqlINSERT2 = "";
         String sqlINSERT = "insert into doctor(last_name, first_name, specialty, practice_since, ssn) values( ?, ?, ?, ?, ?)";
         String[] keycols = {"id"};
         ps = conn.prepareStatement(sqlINSERT, keycols);
       
         // generate 10 doctors
         for (int k=1; k<=10; k++) {
       
            //generate and set doctor last_name
            test = gen.nextInt(names.length);
            lastName = names[test]; 
            ps.setString(1,  lastName);
        
            //generate and set doctor first_name
            test = gen.nextInt(names.length);
            firstName = names[test];      
            ps.setString(2, firstName);
            
            //generate and set doctor specialty
            speciality = specialties[gen.nextInt(specialties.length)];
            ps.setString(3, speciality);
            
            //generate and set year of practice start
            years = Integer.toString(gen.nextInt(2015 - 1975) + 1975);
            ps.setString(4, years);
            
            //generate and set unique ssn
            dssn = generateSsn();
            ps.setString(5, dssn);
            
            
            row_count = ps.executeUpdate();
            System.out.println("row inserted "+row_count);
            
            // retrieve and print the generated primary key
            
            rs = ps.getGeneratedKeys();
            rs.next();
            id = rs.getInt(1);
            System.out.println("row inserted for doctor id "+id);
         }
         
         
         sqlINSERT = "insert into patient(last_name, first_name, birthdate, ssn, street, city, state, zipcode, primaryId) values( ?, ?, ?, ?, ?, ?, ?, ?, ?)";
         keycols = new String[] {"patientId"};
         ps = conn.prepareStatement(sqlINSERT, keycols);
         
         // generate 100 patients
         for (int k=1; k<=100; k++) {
            
            // SSN method ensures that this program generates unique SSNs.
            
            //generate and set lastname
            test = gen.nextInt(names.length);
            lastName = names[test]; 
            ps.setString(1,  lastName);
            
            //generate and set firstname
            test = gen.nextInt(names.length);
            firstName = names[test];      
            ps.setString(2, firstName);
            
            //generate and set birthday
            birthdate = generateBirthday();  
            ps.setString(3, birthdate); // fix date
            
            //generate and set ssn
            pssn = generateSsn();
            ps.setString(4, pssn);
            
            //generate and set street
            genAddress = new Random();
            address = genAddress.nextInt(99999 - 10000) + 10000;
            street = "" + address; 
            test = streets.length;
            street += " " + streets[gen.nextInt(test)];
            ps.setString(5, street);
            
            //generate and set address and city
            test = cities.length;
            city = "" + cities[gen.nextInt(test)];
            ps.setString(6, city);
            
            //generate and set state
            test = states.length;
            state = states[gen.nextInt(test)];
            ps.setString(7, state);
            
            //generate and set zipcode
            zip = genAddress.nextInt(99999 - 10000) + 10000;
            zipcode = "" + zip;
            ps.setString(8, zipcode);
            
            
            //generate and set primaryId
            primaryId = gen.nextInt(10 - 1) + 1;
            ps.setInt(9, primaryId);
            row_count = ps.executeUpdate();
            System.out.println("row inserted "+row_count);
            
            
            
            // retrieve and print the generated primary key
            rs = ps.getGeneratedKeys();
            rs.next();
            id = rs.getInt(1);
            System.out.println("row inserted for patient id "+id);
         }
         
         
      // create 100 prescriptions and fill the last 25 of them
         sqlINSERT = "insert into prescription(doctorId, patientId, drugId, quantity, dateprescribed) values(?, ?, ?, ?, ?)";
         keycols = new String[] {"rxnumber"};
         ps = conn.prepareStatement(sqlINSERT, keycols);
         
         for (int k=1; k<=100; k++) {
            
            //get random doctor from doctor table and add to prescription set
            int doctorId = gen.nextInt(10 - 1) + 1;
            ps.setInt(1, doctorId);
            
            //get random patient from patient table
            int patientId = gen.nextInt(100 - 1) + 1;
            ps.setInt(2, patientId);
            
            //get random drug from table
            int drugId = gen.nextInt(99 - 1) + 1;
            ps.setInt(3, drugId);
            
            //generate and set quantity
            int quantity = gen.nextInt(80 - 25) + 25;
            ps.setInt(4, quantity);
            
            ps.setString(5, generatePrescribedDate());
            
            // retrieve and print the generated primary key
            row_count = ps.executeUpdate();
            System.out.println("row inserted "+row_count);
            rs = ps.getGeneratedKeys();
            rs.next();
            id = rs.getInt(1);
            System.out.println("row inserted for prescription id "+id);
            
            //fill last 25 prescriptions
            if(k > 75)
            {
               sqlINSERT2 = "insert into filled(datefilled, rxid, pharmacyid) values(?, ?, ?)";
             //  keycols2 = new String[] {"rxnumber"};
               ps2 = conn.prepareStatement(sqlINSERT2);
             
               
               SimpleDateFormat simpleDateFormat = 
                     new SimpleDateFormat("YYYY-MM-dd");
                           Calendar c = Calendar.getInstance();
                           c.set(Calendar.YEAR,  2022);
                           c.set(Calendar.DAY_OF_YEAR, 1);
                           c.add(Calendar.DAY_OF_YEAR, gen.nextInt(365));
                           Date dt = new Date(c.getTimeInMillis());
                           String random_date = simpleDateFormat.format(dt);
               
            java.sql.Date sqldate = new java.sql.Date(dt.getTime());
                           
            ps2.setDate(1, sqldate);               
               
            //set rxid in filled table
            ps2.setInt(2, k);   
               
            //generate and set pharmacy id for filled table
            ps2.setInt(3, gen.nextInt(10 - 1) + 1);
            ps2.executeUpdate();
            
            sqlINSERT2 = "update prescription set filled = 'yes' where rxid = ?";
           
          //  keycols2 = new String[] {"rxnumber"};
            ps2 = conn.prepareStatement(sqlINSERT2);
            
            ps2.setInt(1, k);
            ps2.executeUpdate();
            
            }
         }
         //generate random prices for all drugs for all pharmacies
         for(int i = 1; i <= 10; i++)
         {
            sqlINSERT2 = "insert into sold(drugid, pharmacyid, price) values(?, ?, ?)";
            ps2 = conn.prepareStatement(sqlINSERT2);
            
            for(int j = 1; j < 100; j++)
            {
               
               ps2.setInt(1, j);
               ps2.setInt(2, i);
               ps2.setDouble(3, gen.nextDouble(199.99 - 24.99) + 24.00);
               ps2.executeUpdate();
            }
         }
         
         
      } 
      catch (SQLException e) 
      {
         System.out.println("Error: SQLException "+e.getMessage());
      }
      
      
   };
   
}
