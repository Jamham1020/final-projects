package com.testing.csumbcsitprogramlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CST462SActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cst462_sactivity);
    }
}