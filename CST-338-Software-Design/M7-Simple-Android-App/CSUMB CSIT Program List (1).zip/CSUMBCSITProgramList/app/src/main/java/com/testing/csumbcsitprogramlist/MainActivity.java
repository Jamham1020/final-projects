package com.testing.csumbcsitprogramlist;

import android.content.Intent;
import android.widget.MediaController;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);


        ArrayList<String> arrayList = new ArrayList<>();

        arrayList.add("CST-300 Major ProSeminar");
        arrayList.add("CST-338 Software Design");
        arrayList.add("CST-311 Intro to Computer Networks");
        arrayList.add("CST-334 Operating Systems");
        arrayList.add("CST-336 Internet Programming");
        arrayList.add("CST-363 Introduction to Database Systems");
        arrayList.add("CST-370 Design and Analysis of Algorithms");
        arrayList.add("CST-438 Software Engineering");
        arrayList.add("CST-462S Race, Gender, Class in the Digital World");
        arrayList.add("CST-499 Computer Science Capstone");
        arrayList.add("CST-383 Introduction to Data Science");
        arrayList.add("CST-325 Graphics Programming");


        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if(i == 0){
                //click CST 300
                startActivity(new Intent(MainActivity.this, CST300Activity.class));
            }else if(i == 1){
                //click CST 338
                startActivity(new Intent(MainActivity.this, CST338Activity.class));

            }else if(i == 2){
                //click CST 311
                startActivity(new Intent(MainActivity.this, CST311Activity.class));

            }else if(i == 3){
                //click CST 334
                startActivity(new Intent(MainActivity.this, CST334Activity.class));

            }else if(i == 4){
                // click CST 336
                startActivity(new Intent(MainActivity.this, CST336Activity.class));

            }else if(i == 5){
                // click CST 363
                startActivity(new Intent(MainActivity.this, CST363Activity.class));

            }else if(i == 6){
                //click CST 370
                startActivity(new Intent(MainActivity.this, CST370Activity.class));

            }else if(i == 7){
                //click CST 438
                startActivity(new Intent(MainActivity.this, CST438Activity.class));

            }else if(i == 8){
                //click CST 462S
                startActivity(new Intent(MainActivity.this, CST462Activity.class));

            }else if(i == 9){
                //click CST 499
                startActivity(new Intent(MainActivity.this, CST499Activity.class));

            }else if(i == 10){
                //click CST 383
                startActivity(new Intent(MainActivity.this, CST383Activity.class));

            }else{
                //click CST 325
                startActivity(new Intent(MainActivity.this, CST325Activity.class));

            }
        });
        button = findViewById(R.id.buttonone);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),videoactivity.class);
                startActivity(intent);

            }
        });
    }
}